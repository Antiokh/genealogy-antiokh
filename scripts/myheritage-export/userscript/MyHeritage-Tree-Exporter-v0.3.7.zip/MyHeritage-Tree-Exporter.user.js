// ==UserScript==
// @name         MyHeritage Full Personal Exporter
// @namespace    antiokh
// @version      0.3.7
// @description  Persistent MyHeritage exporter: People inventory/detail -> tree sweep -> photo inventory/resolve/download -> JSON export.
// @match        https://www.myheritage.com/*
// @match        https://*.myheritage.com/*
// @run-at       document-start
// @grant        unsafeWindow
// @grant        GM_download
// @connect      sites-cf.mhcache.com
// @connect      *.mhcache.com
// @connect      *.myheritage.com
// ==/UserScript==

(() => {
  'use strict';

  const W = typeof unsafeWindow !== 'undefined' ? unsafeWindow : window;

  const VERSION = '0.3.7';
  const PREFIX = 'MHX__';
  const DB_NAME = 'MHX_MYHERITAGE_EXPORTER';
  const DB_VERSION = 1;

  const DETAIL_TIMEOUT = 9000;
  const TREE_PROFILE_TIMEOUT = 9000;
  const DOM_SETTLE = 650;
  const PAGE_SETTLE = 1200;
  const MAX_DETAIL_ATTEMPTS = 2;
  const MAX_TREE_CENTER_ATTEMPTS = 2;
  const MAX_PHOTO_RESOLVE_ATTEMPTS = 2;
  const PHOTO_WORLD_MIN_INTERVAL = 3500;

  let db = null;
  let dbReady = false;
  let captureQueue = [];
  let activeTreePersonId = null;
  let pageRunnerActive = false;
  let panelTimer = null;
  let currentLog = [];
  let observedCsrfToken = null;

  const session = {
    expandedRidges: new Set(),
    responseFingerprints: new Set(),
    photoResolveCandidates: new Set(),
  };

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const nowIso = () => new Date().toISOString();

  // ---------------------------------------------------------------------------
  // IndexedDB
  // ---------------------------------------------------------------------------

  function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);

      req.onupgradeneeded = () => {
        const d = req.result;

        if (!d.objectStoreNames.contains('meta')) {
          d.createObjectStore('meta', { keyPath: 'key' });
        }

        if (!d.objectStoreNames.contains('people')) {
          const s = d.createObjectStore('people', { keyPath: 'id' });
          s.createIndex('listPage', 'listPage', { unique: false });
        }

        if (!d.objectStoreNames.contains('photos')) {
          d.createObjectStore('photos', { keyPath: 'id' });
        }

        if (!d.objectStoreNames.contains('raw')) {
          const s = d.createObjectStore('raw', {
            keyPath: 'seq',
            autoIncrement: true,
          });
          s.createIndex('kind', 'kind', { unique: false });
          s.createIndex('personId', 'personId', { unique: false });
        }
      };

      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  function requestPromise(req) {
    return new Promise((resolve, reject) => {
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function getStoreValue(store, key) {
    const tx = db.transaction(store, 'readonly');
    return requestPromise(tx.objectStore(store).get(key));
  }

  async function putStoreValue(store, value) {
    const tx = db.transaction(store, 'readwrite');
    await requestPromise(tx.objectStore(store).put(value));
  }

  async function addStoreValue(store, value) {
    const tx = db.transaction(store, 'readwrite');
    return requestPromise(tx.objectStore(store).add(value));
  }

  async function getAllStore(store) {
    const tx = db.transaction(store, 'readonly');
    return requestPromise(tx.objectStore(store).getAll());
  }

  async function clearStore(store) {
    const tx = db.transaction(store, 'readwrite');
    await requestPromise(tx.objectStore(store).clear());
  }

  async function metaGet(key, fallback = null) {
    const row = await getStoreValue('meta', key);
    return row ? row.value : fallback;
  }

  async function metaSet(key, value) {
    await putStoreValue('meta', { key, value, updatedAt: nowIso() });
  }

  async function getCrawler() {
    return await metaGet('crawler', {
      enabled: false,
      phase: 'idle',
      targetId: null,
      lastAction: null,
      startedAt: null,
      updatedAt: null,
    });
  }

  async function patchCrawler(patch) {
    const current = await getCrawler();
    const next = {
      ...current,
      ...patch,
      updatedAt: nowIso(),
    };
    await metaSet('crawler', next);
    return next;
  }

  async function getPerson(id) {
    return getStoreValue('people', String(id));
  }

  async function putPerson(person) {
    person.updatedAt = nowIso();
    await putStoreValue('people', person);
  }

  async function ensurePerson(id, patch = {}) {
    id = String(id);
    const current = await getPerson(id) || {
      id,
      fullId: null,
      listPage: null,
      listRow: null,
      peopleDetail: null,
      treeCard: null,
      treeProfile: null,

      detailAttempts: 0,
      detailFailed: false,

      treeCenterAttempts: 0,
      treeFailed: false,

      photoInventoryScanned: false,
      photoInventoryAttempts: 0,

      createdAt: nowIso(),
    };

    const next = { ...current, ...patch, id };
    await putPerson(next);
    return next;
  }

  async function getPhoto(id) {
    return getStoreValue('photos', String(id));
  }

  async function upsertPhoto(id, patch = {}, ownerId = null) {
    id = String(id);

    const current = await getPhoto(id) || {
      id,
      owners: [],
      pageUrl: null,
      thumbUrl: null,
      largeUrl: null,
      sourceUrls: [],
      discovered: true,
      resolved: false,
      resolveAttempts: 0,
      downloaded: false,
      downloadedAt: null,
      downloadError: null,
      createdAt: nowIso(),
    };

    const owners = new Set(current.owners || []);
    if (ownerId) owners.add(String(ownerId));

    const sourceUrls = new Set(current.sourceUrls || []);
    for (const candidate of [
      patch.pageUrl,
      patch.thumbUrl,
      patch.largeUrl,
      ...(patch.sourceUrls || []),
    ]) {
      if (candidate) sourceUrls.add(candidate);
    }

    const next = {
      ...current,
      ...patch,
      id,
      owners: [...owners],
      sourceUrls: [...sourceUrls],
      updatedAt: nowIso(),
    };

    await putStoreValue('photos', next);
    return next;
  }

  async function saveRaw(kind, personId, url, body) {
    try {
      await addStoreValue('raw', {
        kind,
        personId: personId ? String(personId) : null,
        url: url || location.href,
        capturedAt: nowIso(),
        body,
      });
    } catch (e) {
      log(`raw save failed: ${e.message}`, 'warn');
    }
  }

  function detectAccessIssue() {
    const body = String(document.body?.innerText || '');

    const usageLimit =
      /Maximum usage reached/i.test(body) ||
      /maximum daily usage limit/i.test(body);

    const loggedOut =
      /You are not logged in/i.test(body) &&
      /\bLog in\b/i.test(body);

    return { usageLimit, loggedOut };
  }

  async function guardAccessState() {
    const issue = detectAccessIssue();
    if (!issue.usageLimit && !issue.loggedOut) return false;

    const crawler = await getCrawler();

    // During photo inventory MyHeritage can return a limit/fallback page for
    // one particular person while other people's photo-world pages still work.
    // Let photoInventoryPhase handle that target locally instead of pausing the
    // whole crawler. The same fallback page may also render a logged-out header.
    if (crawler.phase === 'photo-inventory' && issue.usageLimit) {
      return false;
    }

    if (issue.loggedOut) {
      await patchCrawler({
        enabled: false,
        lastAction: 'PAUSED — session is logged out',
      });

      log('crawler paused: session is logged out', 'warn');
      refreshPanel().catch(() => {});
      return true;
    }

    // Outside photo inventory, a usage-limit page is safer to treat as global.
    if (issue.usageLimit) {
      await patchCrawler({
        enabled: false,
        lastAction: 'PAUSED — maximum daily usage reached',
      });

      log('crawler paused: maximum daily usage reached', 'warn');
      refreshPanel().catch(() => {});
      return true;
    }

    return false;
  }

  async function handlePhotoWorldLimitPage() {
    const issue = detectAccessIssue();
    if (!issue.usageLimit) return false;

    const crawler = await getCrawler();
    const targetId = crawler.targetId;

    if (!targetId) {
      // We are sitting on a stale limit/fallback page after finishing a target.
      // Do not classify another person from this page; let the normal scheduler
      // choose and navigate to the next target.
      return false;
    }

    const person = await getPerson(targetId);
    if (!person) {
      await patchCrawler({ targetId: null });
      return true;
    }

    const total = declaredMediaTotal(person);

    // Count photo IDs already known for this person from People detail/tree
    // responses so the export still retains everything discovered elsewhere.
    const photos = await getAllStore('photos');
    const known = photos.filter(ph =>
      (ph.owners || []).includes(String(targetId))
    ).length;

    person.photoInventoryScanned = true;
    person.photoInventoryAttempts =
      (person.photoInventoryAttempts || 0) + 1;
    person.photoInventoryDeclaredTotal = total;
    person.photoInventoryFound = known;
    person.photoInventoryStatus = 'usage-limit-page';
    await putPerson(person);

    log(
      `photo inventory ${targetId}: limit/fallback page; ` +
      `known=${known}` +
      (total != null ? `, declared=${total}` : ''),
      'warn'
    );

    await patchCrawler({
      targetId: null,
      lastAction: `photo inventory ${targetId}: limit page skipped`,
    });

    return true;
  }


  async function throttlePhotoWorldNavigation() {
    const last = Number(await metaGet('lastPhotoWorldNavigationAt', 0)) || 0;
    const wait = PHOTO_WORLD_MIN_INTERVAL - (Date.now() - last);

    if (wait > 0) {
      await sleep(wait);
    }

    await metaSet('lastPhotoWorldNavigationAt', Date.now());
  }

  // ---------------------------------------------------------------------------
  // Generic helpers
  // ---------------------------------------------------------------------------

  function safeName(value, max = 100) {
    return String(value ?? '')
      .normalize('NFKC')
      .replace(/[<>:"/\\|?*\x00-\x1f]/g, '_')
      .replace(/__+/g, '_')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, max);
  }

  function text(el) {
    return String(el?.textContent ?? '').replace(/\s+/g, ' ').trim();
  }

  function attr(el, name) {
    return el?.getAttribute?.(name) ?? null;
  }

  function numericTail(value) {
    if (value == null) return null;
    const m = String(value).match(/(?:^|-)(\d+)$/);
    return m ? m[1] : null;
  }

  function extractPersonIdFromUrl(value) {
    if (!value) return null;
    const s = String(value);

    const patterns = [
      /rootIndividualID=(\d+)/i,
      /individual_id=(\d+)/i,
      /individualId=(\d+)/i,
      /indID=(\d+)/i,
      /individual-[A-Z0-9]+-(\d+)/i,
      /profile-[A-Z0-9]+-(\d+)/i,
      /-(\d+)(?:[/?#]|$)/,
    ];

    for (const re of patterns) {
      const m = s.match(re);
      if (m) return m[1];
    }

    return null;
  }

  function extractPhotoIdFromUrl(value) {
    if (!value) return null;
    const m = String(value).match(/\/photo-(\d+)_/i);
    return m ? m[1] : null;
  }

  function absoluteUrl(value) {
    if (!value) return null;
    try {
      return new URL(value, location.href).href;
    } catch {
      return null;
    }
  }

  function parseBackgroundUrl(styleValue) {
    if (!styleValue) return null;
    const m = String(styleValue).match(/url\((['"]?)(.*?)\1\)/i);
    return m ? absoluteUrl(m[2]) : null;
  }

  function eventPoint(el) {
    const r = el.getBoundingClientRect();
    return {
      clientX: r.left + Math.max(1, r.width / 2),
      clientY: r.top + Math.max(1, r.height / 2),
    };
  }

  function syntheticClick(el) {
    if (!el) return false;
    const point = eventPoint(el);
    const common = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: W,
      button: 0,
      buttons: 1,
      ...point,
    };

    try {
      if (W.PointerEvent) {
        el.dispatchEvent(new W.PointerEvent('pointerdown', common));
      }
    } catch {}

    el.dispatchEvent(new W.MouseEvent('mousedown', common));

    try {
      if (W.PointerEvent) {
        el.dispatchEvent(new W.PointerEvent(
          'pointerup',
          { ...common, buttons: 0 }
        ));
      }
    } catch {}

    el.dispatchEvent(new W.MouseEvent(
      'mouseup',
      { ...common, buttons: 0 }
    ));
    el.dispatchEvent(new W.MouseEvent(
      'click',
      { ...common, buttons: 0 }
    ));

    return true;
  }

  function elementUsable(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) return false;
    const s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden';
  }

  function waitFor(test, timeout = 8000, interval = 120) {
    const started = Date.now();

    return new Promise(resolve => {
      const tick = async () => {
        try {
          const result = await test();
          if (result) return resolve(result);
        } catch {}

        if (Date.now() - started >= timeout) return resolve(null);
        setTimeout(tick, interval);
      };

      tick();
    });
  }

  async function waitForDomReady() {
    if (document.readyState === 'loading') {
      await new Promise(resolve =>
        document.addEventListener('DOMContentLoaded', resolve, { once: true })
      );
    }
  }

  function downloadBlob(filename, data, type = 'application/json;charset=utf-8') {
    const blob = data instanceof Blob ? data : new Blob([data], { type });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.style.display = 'none';
    document.documentElement.appendChild(a);
    a.click();
    a.remove();

    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }

  // ---------------------------------------------------------------------------
  // Site/tree identity
  // ---------------------------------------------------------------------------

  function detectContext() {
    const u = new URL(location.href);
    const path = u.pathname;

    let siteId = null;
    let treeSlug = null;
    let treeId = null;

    let m = path.match(/^\/people-([^/]+)\/([^/?#]+)/i);
    if (m) {
      siteId = m[1];
      treeSlug = m[2];
    }

    m = path.match(/^\/family-trees\/([^/]+)\/([^/?#]+)/i);
    if (m) {
      treeSlug = m[1];
      siteId = m[2];
      treeId = u.searchParams.get('familyTreeID') || treeId;
    }

    m = path.match(/^\/photo-world\/([^/?#]+)/i);
    if (m) {
      siteId = m[1];
      treeId = u.searchParams.get('tree_id') || treeId;
    }

    m = path.match(/^\/photo-\d+_([^_/?#]+)_([^/?#]+)/i);
    if (m) {
      siteId = m[1];
    }

    return {
      siteId,
      treeSlug,
      treeId: treeId || '1',
    };
  }

  async function persistDetectedContext() {
    const detected = detectContext();
    const old = await metaGet('site', {});

    const next = {
      ...old,
      ...Object.fromEntries(
        Object.entries(detected).filter(([, v]) => v)
      ),
    };

    if (JSON.stringify(old) !== JSON.stringify(next)) {
      await metaSet('site', next);
    }

    return next;
  }

  async function getSite() {
    const detected = await persistDetectedContext();
    return detected;
  }

  async function peopleUrl(page = 1) {
    const site = await getSite();
    if (!site.siteId || !site.treeSlug) return null;

    return (
      `https://www.myheritage.com/people-${site.siteId}/${site.treeSlug}` +
      `#page=${page}&sort=relationship`
    );
  }

  async function constructedTreeUrl(personId) {
    const site = await getSite();
    if (!site.siteId || !site.treeSlug) return null;

    return (
      `https://www.myheritage.com/family-trees/${site.treeSlug}/${site.siteId}` +
      `?familyTreeID=${encodeURIComponent(site.treeId || '1')}` +
      `&rootIndividualID=${encodeURIComponent(personId)}`
    );
  }

  async function photoWorldUrl(personId) {
    const site = await getSite();
    if (!site.siteId) return null;

    return (
      `https://www.myheritage.com/photo-world/${site.siteId}` +
      `?tree_id=${encodeURIComponent(site.treeId || '1')}` +
      `&individual_id=${encodeURIComponent(personId)}`
    );
  }

  async function navigate(url, reason) {
    if (!url) {
      log(`cannot navigate (${reason}): target URL unavailable`, 'warn');
      await patchCrawler({ enabled: false, lastAction: `navigation failed: ${reason}` });
      return;
    }

    await patchCrawler({ lastAction: reason });
    log(`navigate: ${reason}`);
    location.href = url;
  }

  function csrfFromUrl(value) {
    if (!value) return null;

    try {
      const u = new URL(String(value), location.href);
      const token = u.searchParams.get('csrf_token');
      if (token) return token;
    } catch {}

    const m = String(value).match(/[?&]csrf_token=([^&#"'\s]+)/i);
    if (!m) return null;

    try {
      return decodeURIComponent(m[1]);
    } catch {
      return m[1];
    }
  }

  async function rememberCsrfToken(token) {
    if (!token) return null;
    observedCsrfToken = String(token);

    if (dbReady) {
      await metaSet('csrfToken', observedCsrfToken);
    }

    return observedCsrfToken;
  }

  function discoverCsrfTokenInDocument() {
    const direct = [
      document.querySelector('input[name="csrf_token"]')?.value,
      document.querySelector('meta[name="csrf-token"]')?.content,
      document.querySelector('meta[name="csrf_token"]')?.content,
      document.documentElement?.getAttribute?.('data-csrf-token'),
    ].find(Boolean);

    if (direct) return String(direct);

    try {
      for (const entry of performance.getEntriesByType('resource')) {
        const token = csrfFromUrl(entry.name);
        if (token) return token;
      }
    } catch {}

    // MyHeritage often embeds the token in page bootstrap JS/config.
    // Scan script text first; this is much cheaper than serializing the full DOM.
    for (const script of document.scripts) {
      const body = script.textContent || '';

      const urlMatch = body.match(/csrf_token=([A-Za-z0-9._-]+)/i);
      if (urlMatch) return urlMatch[1];

      const propMatch = body.match(
        /["']?csrf_token["']?\s*[:=]\s*["']([^"']+)["']/i
      );
      if (propMatch) return propMatch[1];
    }

    return null;
  }

  async function getCsrfToken() {
    const live = discoverCsrfTokenInDocument();
    if (live) {
      await rememberCsrfToken(live);
      return live;
    }

    if (observedCsrfToken) return observedCsrfToken;

    const stored = await metaGet('csrfToken', null);
    if (stored) {
      observedCsrfToken = stored;
      return stored;
    }

    return null;
  }

  // ---------------------------------------------------------------------------
  // Network interception
  // ---------------------------------------------------------------------------

  function looksLikeTreeJson(x) {
    return !!(
      x &&
      typeof x === 'object' &&
      x.data &&
      Array.isArray(x.data.personCards)
    );
  }

  function looksLikePeopleDetailJson(x) {
    return !!(
      x &&
      typeof x === 'object' &&
      x.status === 'success' &&
      x.data &&
      x.data.person &&
      typeof x.data.person === 'object' &&
      (
        Array.isArray(x.data.facts) ||
        Array.isArray(x.data.families) ||
        x.data.media
      )
    );
  }

  function looksLikeTreeProfileJson(x) {
    return !!(
      x &&
      typeof x === 'object' &&
      x.success === true &&
      typeof x.name === 'string' &&
      (
        Array.isArray(x.facts) ||
        Array.isArray(x.relatives) ||
        Array.isArray(x.relativeFamilies) ||
        Array.isArray(x.photos)
      )
    );
  }

  function extractTreeProfileId(profile) {
    for (const candidate of [
      profile?.fullProfileLink,
      profile?.researchURL,
      profile?.viewPhotosURL,
    ]) {
      const id = extractPersonIdFromUrl(candidate);
      if (id) return id;
    }

    if (Array.isArray(profile?.facts)) {
      const own = profile.facts.find(f => {
        if (!f?.individualId) return false;
        const title = String(f.title ?? '');
        return (
          ['BIRT', 'DEAT'].includes(f.type) &&
          !/^Birth of /i.test(title) &&
          !/^Death of /i.test(title)
        );
      });

      if (own?.individualId != null) {
        return String(own.individualId);
      }
    }

    return activeTreePersonId;
  }

  function responseFingerprint(kind, id, payload) {
    return [
      kind,
      id || '',
      payload?.name || payload?.data?.person?.name || '',
      payload?.data?.familyTreeSize || '',
      payload?.facts?.length || payload?.data?.facts?.length || '',
      payload?.photos?.length || payload?.data?.media?.total || '',
      JSON.stringify(payload).length,
    ].join('|');
  }

  function collectImageCandidatesDeep(value, out = new Set(), depth = 0) {
    if (depth > 7 || value == null) return out;

    if (typeof value === 'string') {
      if (
        /^https?:\/\//i.test(value) &&
        /(mhcache|myheritageimages|myheritage\.com)/i.test(value) &&
        /\.(?:jpe?g|png|webp)(?:[?#]|$)/i.test(value)
      ) {
        out.add(value);
      }
      return out;
    }

    if (Array.isArray(value)) {
      for (const item of value) {
        collectImageCandidatesDeep(item, out, depth + 1);
      }
      return out;
    }

    if (typeof value === 'object') {
      for (const item of Object.values(value)) {
        collectImageCandidatesDeep(item, out, depth + 1);
      }
    }

    return out;
  }

  async function absorbJson(payload, url = '', requestMeta = null) {
    if (!dbReady) {
      captureQueue.push({ payload, url });
      return;
    }

    let kind = null;
    let personId = null;

    if (looksLikePeopleDetailJson(payload)) {
      kind = 'people-detail';
      personId =
        numericTail(payload.data.person.id) ||
        extractPersonIdFromUrl(payload.data.person.treePageLink);
    } else if (looksLikeTreeJson(payload)) {
      kind = 'tree';
      personId = payload?.data?.rootIndividualID
        ? String(payload.data.rootIndividualID)
        : null;
    } else if (looksLikeTreeProfileJson(payload)) {
      kind = 'tree-profile';
      personId = extractTreeProfileId(payload);
    }

    // On a photo page, even unrecognized JSON may expose a better image URL.
    if (/^\/photo-\d+_/i.test(location.pathname)) {
      for (const imageUrl of collectImageCandidatesDeep(payload)) {
        session.photoResolveCandidates.add(imageUrl);
      }
    }

    if (!kind) return;

    const fp = responseFingerprint(kind, personId, payload);
    if (session.responseFingerprints.has(fp)) return;
    session.responseFingerprints.add(fp);

    if (kind === 'people-detail') {
      await absorbPeopleDetail(personId, payload, url, requestMeta);
    } else if (kind === 'tree') {
      await absorbTree(payload, url);
    } else if (kind === 'tree-profile') {
      await absorbTreeProfile(personId, payload, url);
    }
  }

  function tryParseJsonText(raw, url) {
    if (typeof raw !== 'string') return;
    const s = raw.trim();
    if (!s || (s[0] !== '{' && s[0] !== '[')) return;

    try {
      absorbJson(JSON.parse(s), url).catch(e => {
        log(`capture handling failed: ${e.message}`, 'warn');
      });
    } catch {}
  }

  function headersToObject(value) {
    const result = {};
    try {
      const headers = new Headers(value || {});
      for (const [key, val] of headers.entries()) {
        result[key] = val;
      }
    } catch {}
    return result;
  }

  function serializableBody(body) {
    if (body == null) return null;
    if (typeof body === 'string') return body;
    if (body instanceof URLSearchParams) return body.toString();

    // FormData is uncommon here but preserve simple string fields when possible.
    if (typeof FormData !== 'undefined' && body instanceof FormData) {
      const obj = {};
      for (const [key, val] of body.entries()) {
        if (typeof val === 'string') obj[key] = val;
      }
      return {
        __mhxType: 'formdata',
        fields: obj,
      };
    }

    return null;
  }

  function installFetchHook() {
    if (W.__MHX_V03_FETCH__) return;
    W.__MHX_V03_FETCH__ = true;

    const original = W.fetch;
    if (typeof original !== 'function') return;

    // Keep an unwrapped function for direct replay so our own request does not
    // recurse through the recorder. We still feed its response to absorbJson.
    W.__MHX_NATIVE_FETCH__ = original;

    W.fetch = function (input, init = {}) {
      const url =
        typeof input === 'string' || input instanceof URL
          ? String(input)
          : String(input?.url || '');

      const csrf = csrfFromUrl(url);
      if (csrf) rememberCsrfToken(csrf).catch(() => {});

      const requestMeta = {
        transport: 'fetch',
        method: String(
          init?.method || input?.method || 'GET'
        ).toUpperCase(),
        url: absoluteUrl(url) || url,
        headers: {
          ...headersToObject(input?.headers),
          ...headersToObject(init?.headers),
        },
        body: serializableBody(init?.body),
        replayed: false,
      };

      const p = original.apply(this, [input, init]);

      p.then(response => {
        try {
          response.clone().text().then(body => {
            const s = body.trim();
            if (!s || (s[0] !== '{' && s[0] !== '[')) return;

            try {
              absorbJson(
                JSON.parse(s),
                response.url,
                requestMeta
              ).catch(() => {});
            } catch {}
          }).catch(() => {});
        } catch {}
      }).catch(() => {});

      return p;
    };
  }

  function installXhrHook() {
    if (W.__MHX_V03_XHR__) return;
    W.__MHX_V03_XHR__ = true;

    const XHR = W.XMLHttpRequest;
    if (!XHR?.prototype) return;

    const originalOpen = XHR.prototype.open;
    const originalSend = XHR.prototype.send;
    const originalSetRequestHeader = XHR.prototype.setRequestHeader;

    XHR.prototype.open = function (method, url, ...rest) {
      this.__mhxUrl = String(url ?? '');

      const csrf = csrfFromUrl(this.__mhxUrl);
      if (csrf) rememberCsrfToken(csrf).catch(() => {});

      this.__mhxMethod = String(method || 'GET').toUpperCase();
      this.__mhxHeaders = {};
      return originalOpen.call(this, method, url, ...rest);
    };

    XHR.prototype.setRequestHeader = function (name, value) {
      try {
        this.__mhxHeaders[String(name).toLowerCase()] = String(value);
      } catch {}
      return originalSetRequestHeader.call(this, name, value);
    };

    XHR.prototype.send = function (body, ...rest) {
      this.__mhxBody = serializableBody(body);

      if (!this.__mhxHooked) {
        this.__mhxHooked = true;

        this.addEventListener('load', () => {
          try {
            const url = this.responseURL || this.__mhxUrl || '';
            const requestMeta = {
              transport: 'xhr',
              method: this.__mhxMethod || 'GET',
              url: absoluteUrl(this.__mhxUrl) || this.__mhxUrl || url,
              headers: this.__mhxHeaders || {},
              body: this.__mhxBody ?? null,
              replayed: false,
            };

            if (this.responseType === 'json' && this.response) {
              absorbJson(
                this.response,
                url,
                requestMeta
              ).catch(() => {});
            } else if (!this.responseType || this.responseType === 'text') {
              const s = String(this.responseText || '').trim();
              if (!s || (s[0] !== '{' && s[0] !== '[')) return;

              try {
                absorbJson(
                  JSON.parse(s),
                  url,
                  requestMeta
                ).catch(() => {});
              } catch {}
            }
          } catch {}
        });
      }

      return originalSend.call(this, body, ...rest);
    };
  }

  installFetchHook();
  installXhrHook();

  // ---------------------------------------------------------------------------
  // Captured JSON handlers
  // ---------------------------------------------------------------------------

  async function absorbPeopleDetail(personId, payload, url, requestMeta = null) {
    if (!personId) {
      log('people detail received without person id', 'warn');
      return;
    }

    const data = payload.data;
    const person = data.person;

    // Learn the exact working request from one real user click. We only learn
    // from a genuine page request, never from our own replay.
    if (requestMeta && !requestMeta.replayed) {
      const template = {
        ...requestMeta,
        sourcePersonId: String(personId),
        sourceFullId: person.id || null,
        learnedAt: nowIso(),
      };

      await metaSet('peopleDetailRequestTemplate', template);
      log(
        `learned people-detail API: ` +
        `${template.method} ${template.url}`
      );
    }

    const p = await ensurePerson(personId, {
      fullId: person.id || null,
      peopleDetail: data,
      detailFailed: false,
    });

    // This response itself gives a reliable tree URL.
    if (person.treePageLink) {
      p.treePageLink = absoluteUrl(person.treePageLink);
      await putPerson(p);
    }

    // Media here may be partial; collect it but do not mark photo inventory complete.
    for (const item of data.media?.items ?? []) {
      const photoId = numericTail(item.id) || extractPhotoIdFromUrl(item.link);
      if (!photoId) continue;

      await upsertPhoto(photoId, {
        pageUrl: absoluteUrl(item.link),
        thumbUrl: absoluteUrl(item.url),
        discovered: true,
      }, personId);
    }

    await saveRaw('people-detail', personId, url, payload);
    log(`people detail ${personId}: ${person.name || ''}`);
    refreshPanel().catch(() => {});

    const crawler = await getCrawler();
    if (
      crawler.enabled &&
      crawler.phase === 'people-detail' &&
      !requestMeta?.replayed
    ) {
      setTimeout(() => {
        runCurrentPhase().catch(e => log(e.message, 'warn'));
      }, 250);
    }
  }

  async function absorbTree(payload, url) {
    const data = payload.data;

    if (data.familyTreeSize != null) {
      await metaSet('familyTreeSize', Number(data.familyTreeSize));
    }

    if (data.rootIndividualID != null) {
      await metaSet('lastTreeRootId', String(data.rootIndividualID));
    }

    for (const card of data.personCards ?? []) {
      if (!card?.id || String(card.id).startsWith('addme_')) continue;
      await ensurePerson(String(card.id), { treeCard: card });
    }

    await saveRaw(
      'tree',
      data.rootIndividualID ? String(data.rootIndividualID) : null,
      url,
      payload
    );

    log(
      `tree response: cards=${data.personCards?.length ?? 0}, ` +
      `size=${data.familyTreeSize ?? '?'}`
    );
    refreshPanel().catch(() => {});
  }

  async function absorbTreeProfile(personId, payload, url) {
    if (!personId) {
      log(`tree profile without ID: ${payload.name}`, 'warn');
      return;
    }

    await ensurePerson(personId, {
      treeProfile: payload,
      treeFailed: false,
    });

    for (const ph of payload.photos ?? []) {
      const photoId =
        ph.id != null ? String(ph.id) : extractPhotoIdFromUrl(ph.pageUrl);

      if (!photoId) continue;

      await upsertPhoto(photoId, {
        pageUrl: absoluteUrl(ph.pageUrl),
        thumbUrl: absoluteUrl(ph.thumbUrl),
        largeUrl: absoluteUrl(ph.largeUrl),
        resolved: !!ph.largeUrl,
        discovered: true,
      }, personId);
    }

    await saveRaw('tree-profile', personId, url, payload);
    log(`tree profile ${personId}: ${payload.name}`);
    refreshPanel().catch(() => {});
  }

  // ---------------------------------------------------------------------------
  // People list inventory
  // ---------------------------------------------------------------------------

  function currentPeoplePage() {
    const params = new URLSearchParams(location.hash.replace(/^#/, ''));
    return Math.max(1, Number(params.get('page') || '1') || 1);
  }

  function parsePeopleTotal() {
    const body = text(document.body);

    const patterns = [
      /Showing\s+\d+\s*[-–]\s*\d+\s+of\s+(\d+)\s+people/i,
      /\b\d+\s+of\s+(\d+)\s+people\b/i,
    ];

    for (const re of patterns) {
      const m = body.match(re);
      if (m) return Number(m[1]);
    }

    return null;
  }

  function peopleRows() {
    return [
      ...document.querySelectorAll(
        '.people_list_item[data-person-id], [role="row"][data-person-id]'
      ),
    ];
  }

  function parseListRow(row, page) {
    const fullId = attr(row, 'data-person-id');
    const id = numericTail(fullId);
    if (!id) return null;

    const birth = row.querySelector('.column_birth');
    const death = row.querySelector('.column_death');

    const photoEl = row.querySelector('.item_photo');
    const photo =
      parseBackgroundUrl(photoEl?.style?.backgroundImage) ||
      parseBackgroundUrl(getComputedStyle(photoEl || row).backgroundImage);

    return {
      id,
      fullId,
      listPage: page,
      listRow: {
        name: text(row.querySelector('.item_name')),
        relationship: text(row.querySelector('.item_relationship')),
        birthDate: text(birth?.querySelector('.item_date')),
        birthPlace: text(birth?.querySelector('.item_place')),
        deathDate: text(death?.querySelector('.item_date')),
        deathPlace: text(death?.querySelector('.item_place')),
        thumbnail: photo,
      },
    };
  }

  async function scanPeopleInventoryPage() {
    const page = currentPeoplePage();

    await waitFor(
      () => peopleRows().length > 0 ? peopleRows() : null,
      10000
    );

    const rows = peopleRows();
    if (!rows.length) {
      log(`inventory page ${page}: no rows`, 'warn');
      return false;
    }

    for (const row of rows) {
      const parsed = parseListRow(row, page);
      if (!parsed) continue;

      await ensurePerson(parsed.id, {
        fullId: parsed.fullId,
        listPage: parsed.listPage,
        listRow: parsed.listRow,
      });
    }

    const total = parsePeopleTotal();
    if (total) {
      await metaSet('familyTreeSize', total);
    }

    const all = await getAllStore('people');

    log(
      `inventory page ${page}: rows=${rows.length}, ` +
      `inventory=${all.filter(p => p.listRow).length}/${total ?? '?'}`
    );

    return true;
  }

  async function goToPeoplePage(page) {
    const site = await getSite();
    if (!site.siteId || !site.treeSlug) return false;

    const params = currentPeopleHashParams();
    const currentPage = Math.max(1, Number(params.get('page') || '1') || 1);
    const hasPerson = params.has('ind');

    if (
      location.pathname.startsWith(`/people-${site.siteId}/${site.treeSlug}`) &&
      currentPage === Number(page) &&
      !hasPerson
    ) {
      return true;
    }

    const target = await peopleUrl(page);

    if (location.pathname.startsWith('/people-')) {
      params.set('page', String(page));
      params.set('sort', params.get('sort') || 'relationship');
      params.delete('ind');

      location.replace(`#${params.toString()}`);
      await sleep(PAGE_SETTLE);
      return true;
    }

    await navigate(target, `people page ${page}`);
    return false;
  }

  async function inventoryPhase() {
    if (!location.pathname.startsWith('/people-')) {
      await navigate(await peopleUrl(1), 'start inventory');
      return;
    }

    const page = currentPeoplePage();
    await scanPeopleInventoryPage();

    const total = await metaGet('familyTreeSize', null);
    const pageCount = total ? Math.ceil(total / 100) : null;

    if (pageCount && page < pageCount) {
      await goToPeoplePage(page + 1);
      await sleep(PAGE_SETTLE);
      if (location.pathname.startsWith('/people-')) {
        await inventoryPhase();
      }
      return;
    }

    const all = await getAllStore('people');
    const inventoryCount = all.filter(p => p.listRow).length;

    if (total && inventoryCount < total) {
      log(
        `inventory incomplete: ${inventoryCount}/${total}; restarting page 1`,
        'warn'
      );
      await goToPeoplePage(1);
      return;
    }

    await patchCrawler({
      phase: 'people-detail',
      lastAction: `inventory complete ${inventoryCount}/${total ?? inventoryCount}`,
    });

    log(`inventory complete: ${inventoryCount}/${total ?? inventoryCount}`);
    await peopleDetailPhase();
  }

  // ---------------------------------------------------------------------------
  // People detail phase
  // ---------------------------------------------------------------------------

  async function nextMissingPeopleDetail() {
    const people = await getAllStore('people');

    return people
      .filter(p =>
        p.listRow &&
        !p.peopleDetail &&
        !p.detailFailed &&
        (p.detailAttempts || 0) < MAX_DETAIL_ATTEMPTS
      )
      .sort((a, b) =>
        (a.listPage || 999) - (b.listPage || 999) ||
        Number(a.id) - Number(b.id)
      )[0] || null;
  }

  function rowForPerson(person) {
    if (!person) return null;

    if (person.fullId) {
      const byFull = document.querySelector(
        `.people_list_item[data-person-id="${CSS.escape(person.fullId)}"]`
      );
      if (byFull) return byFull;
    }

    return [...peopleRows()].find(row =>
      numericTail(attr(row, 'data-person-id')) === person.id
    ) || null;
  }

  function currentPeopleHashParams() {
    return new URLSearchParams(location.hash.replace(/^#/, ''));
  }

  async function openPeopleDetailByHash(person) {
    const page = Number(person.listPage || currentPeoplePage() || 1);
    const id = String(person.id);

    const params = currentPeopleHashParams();
    params.set('page', String(page));
    params.set('sort', params.get('sort') || 'relationship');

    // If the same person is already in the hash but its JSON was not captured,
    // pulse the hash once so MyHeritage receives a real hashchange again.
    if (params.get('ind') === id) {
      params.delete('ind');
      location.replace(`#${params.toString()}`);
      await sleep(100);
    }

    params.set('ind', id);
    const desiredHash = `#${params.toString()}`;

    log(`detail hash ${id}: ${desiredHash}`);

    // Fragment-only location.replace does not reload the document. It also
    // replaces the current history entry, avoiding hundreds of Back entries.
    location.replace(desiredHash);

    return !!(await waitForPeopleDetail(id, 3500));
  }

  function peopleRowClickTargets(row) {
    // MyHeritage's People list does not expose an onclick on the outer row.
    // Manual clicks land on descendants inside column_person, so emit the event
    // from the same kind of target instead of using target=row.
    const selectors = [
      '.column_person .item_name bdi',
      '.column_person .item_name',
      '.column_person .item_details',
      '.column_person',
    ];

    const targets = selectors
      .map(selector => row.querySelector(selector))
      .filter(Boolean);

    // Keep the outer row only as the final fallback.
    targets.push(row);

    return [...new Set(targets)];
  }

  async function clickPeopleRowUntilDetail(person) {
    const row = rowForPerson(person);
    if (!row) return false;

    // The People list is scrollable. Make the target genuinely visible first;
    // this also matches the conditions under which a human click succeeds.
    try {
      row.scrollIntoView({
        block: 'center',
        inline: 'nearest',
        behavior: 'instant',
      });
    } catch {
      row.scrollIntoView();
    }

    await sleep(120);

    for (const target of peopleRowClickTargets(row)) {
      log(
        `detail click target ${person.id}: ` +
        `${target.className || target.tagName}`
      );

      // Native click first (lets the browser run the element's normal click
      // activation), followed by the fuller mouse sequence for older handlers.
      try {
        target.click();
      } catch {}

      syntheticClick(target);

      const detail = await waitForPeopleDetail(person.id, 2200);
      if (detail) return true;

      await sleep(120);
    }

    return false;
  }

  async function waitForPeopleDetail(id, timeout = DETAIL_TIMEOUT) {
    return waitFor(async () => {
      const p = await getPerson(id);
      return p?.peopleDetail || null;
    }, timeout);
  }

  function replacePersonTokens(value, template, target) {
    if (value == null) return value;
    if (typeof value !== 'string') return value;

    let out = value;

    const pairs = [
      [template.sourceFullId, target.fullId],
      [template.sourcePersonId, target.id],
    ].filter(([from, to]) => from && to);

    for (const [from, to] of pairs) {
      const variants = [
        [String(from), String(to)],
        [encodeURIComponent(String(from)), encodeURIComponent(String(to))],
      ];

      for (const [a, b] of variants) {
        out = out.split(a).join(b);
      }
    }

    return out;
  }

  function specializePeopleDetailRequest(template, target) {
    const headers = {};

    for (const [key, val] of Object.entries(template.headers || {})) {
      const k = String(key).toLowerCase();

      // Browsers forbid these on fetch and supply them automatically.
      if (
        [
          'cookie',
          'host',
          'content-length',
          'origin',
          'referer',
          'user-agent',
          'connection',
        ].includes(k) ||
        k.startsWith('sec-')
      ) {
        continue;
      }

      headers[key] = replacePersonTokens(
        String(val),
        template,
        target
      );
    }

    let body = template.body;

    if (body?.__mhxType === 'formdata') {
      const form = new FormData();

      for (const [key, val] of Object.entries(body.fields || {})) {
        form.append(
          key,
          replacePersonTokens(String(val), template, target)
        );
      }

      body = form;

      // Let fetch generate the multipart boundary.
      for (const key of Object.keys(headers)) {
        if (key.toLowerCase() === 'content-type') delete headers[key];
      }
    } else if (typeof body === 'string') {
      body = replacePersonTokens(body, template, target);
    }

    return {
      transport: 'replay',
      method: template.method || 'GET',
      url: replacePersonTokens(template.url, template, target),
      headers,
      body,
      replayed: true,
      targetId: target.id,
    };
  }

  async function requestPeopleDetailDirect(person) {
    const site = await getSite();
    const csrf = await getCsrfToken();

    if (!site.siteId || !site.treeSlug) {
      log('cannot build People detail URL: site identity missing', 'warn');
      return { ready: false, ok: false, reason: 'site identity missing' };
    }

    if (!csrf) {
      return { ready: false, ok: false, reason: 'csrf token missing' };
    }

    const url =
      `https://www.myheritage.com/` +
      `pedigree-tree-${site.siteId}-${person.id}/` +
      `${site.treeSlug}` +
      `?action=panel&path=&csrf_token=${encodeURIComponent(csrf)}`;

    log(`detail API ${person.id}`);

    let response;

    try {
      response = await (W.__MHX_NATIVE_FETCH__ || W.fetch).call(W, url, {
        method: 'GET',
        credentials: 'include',
        cache: 'no-store',
        headers: {
          'Accept': 'application/json, text/javascript, */*; q=0.01',
          'X-Requested-With': 'XMLHttpRequest',
        },
      });
    } catch (e) {
      log(`detail API network error ${person.id}: ${e.message}`, 'warn');
      return { ready: true, ok: false, reason: e.message };
    }

    // A token can expire during a long crawl. Forget it on auth/CSRF-like
    // failures so the next pass tries to rediscover a fresh one.
    if ([401, 403, 419].includes(response.status)) {
      observedCsrfToken = null;
      await metaSet('csrfToken', null);

      log(
        `detail API HTTP ${response.status}; CSRF token cleared`,
        'warn'
      );
      return {
        ready: false,
        ok: false,
        reason: `HTTP ${response.status}`,
      };
    }

    if (!response.ok) {
      log(
        `detail API HTTP ${response.status} for ${person.id}`,
        'warn'
      );
      return {
        ready: true,
        ok: false,
        reason: `HTTP ${response.status}`,
      };
    }

    let payload;

    try {
      payload = await response.json();
    } catch {
      log(`detail API returned non-JSON for ${person.id}`, 'warn');
      return {
        ready: true,
        ok: false,
        reason: 'non-JSON response',
      };
    }

    if (!looksLikePeopleDetailJson(payload)) {
      log(`detail API unexpected JSON for ${person.id}`, 'warn');
      return {
        ready: true,
        ok: false,
        reason: 'unexpected JSON',
      };
    }

    const actualId =
      numericTail(payload.data?.person?.id) ||
      extractPersonIdFromUrl(payload.data?.person?.treePageLink);

    if (actualId && actualId !== person.id) {
      log(
        `detail API mismatch: wanted ${person.id}, got ${actualId}`,
        'warn'
      );
      return {
        ready: true,
        ok: false,
        reason: `ID mismatch ${actualId}`,
      };
    }

    await absorbPeopleDetail(
      person.id,
      payload,
      response.url,
      {
        transport: 'direct',
        method: 'GET',
        url,
        body: null,
        headers: {
          accept: 'application/json, text/javascript, */*; q=0.01',
          'x-requested-with': 'XMLHttpRequest',
        },
        replayed: true,
      }
    );

    return { ready: true, ok: true };
  }


  async function peopleDetailPhase() {
    if (!location.pathname.startsWith('/people-')) {
      const next = await nextMissingPeopleDetail();

      if (!next) {
        await finishPeopleDetailPhase();
        return;
      }

      await navigate(await peopleUrl(next.listPage || 1), 'people detail page');
      return;
    }

    const next = await nextMissingPeopleDetail();

    if (!next) {
      await finishPeopleDetailPhase();
      return;
    }

    if (currentPeoplePage() !== Number(next.listPage || 1)) {
      await goToPeoplePage(next.listPage || 1);
      await sleep(PAGE_SETTLE);
      await peopleDetailPhase();
      return;
    }

    await waitFor(() => rowForPerson(next), 8000);
    const row = rowForPerson(next);

    if (!row) {
      next.detailAttempts = (next.detailAttempts || 0) + 1;
      if (next.detailAttempts >= MAX_DETAIL_ATTEMPTS) {
        next.detailFailed = true;
      }
      await putPerson(next);
      log(`detail row not found ${next.id}`, 'warn');
      await peopleDetailPhase();
      return;
    }

    log(`detail target ${next.id}: ${next.listRow?.name || ''}`);

    const result = await requestPeopleDetailDirect(next);

    if (!result.ready) {
      // The request format is known. The only missing dynamic ingredient can
      // be the current CSRF token. Do not burn attempts while waiting for it.
      await patchCrawler({
        lastAction:
          `WAITING FOR CSRF TOKEN — ${result.reason || 'not found'}`
      });
      log(
        `People-detail endpoint known, but CSRF token is unavailable. ` +
        `Open one person once or reload the People page to expose a fresh token.`,
        'warn'
      );
      return;
    }

    next.detailAttempts = (next.detailAttempts || 0) + 1;
    await putPerson(next);

    if (!result.ok) {
      const latest = await getPerson(next.id);
      if ((latest.detailAttempts || 0) >= MAX_DETAIL_ATTEMPTS) {
        latest.detailFailed = true;
        await putPerson(latest);
      }
      log(`detail API failed ${next.id}`, 'warn');
    }

    await sleep(120);
    await peopleDetailPhase();
  }

  async function finishPeopleDetailPhase() {
    const people = await getAllStore('people');
    const complete = people.filter(p => p.peopleDetail).length;
    const failed = people.filter(p => p.detailFailed && !p.peopleDetail).length;

    log(`people detail complete=${complete}, failed=${failed}`);

    await patchCrawler({
      phase: 'tree',
      targetId: null,
      lastAction: 'people detail phase finished',
    });

    await treePhase();
  }

  // ---------------------------------------------------------------------------
  // Tree phase
  // ---------------------------------------------------------------------------

  function treeCardsDom() {
    return [
      ...document.querySelectorAll(
        'g[data-type="_svgOuterGroup"][data-individual-id]'
      ),
    ].filter(el => {
      const id = attr(el, 'data-individual-id');
      return id && !String(id).startsWith('addme_');
    });
  }

  function cardWrapper(personEl) {
    return personEl?.querySelector(
      'g[data-type="frameGroup"].cardWrapper, g.cardWrapper[data-type="frameGroup"]'
    );
  }

  function openRidges() {
    return [
      ...document.querySelectorAll(
        'g.ridgeIcon[aria-label="View family branch"]'
      ),
    ].filter(elementUsable);
  }

  function ridgeKey(ridge) {
    const parent = ridge.parentElement;
    const siblings = parent
      ? [...parent.children]
      : [];

    const index = siblings.indexOf(ridge);

    return [
      attr(ridge, 'transform') || '',
      attr(parent, 'transform') || '',
      index,
    ].join('|');
  }

  async function waitForTreeProfile(id, timeout = TREE_PROFILE_TIMEOUT) {
    return waitFor(async () => {
      const p = await getPerson(id);
      return p?.treeProfile || null;
    }, timeout);
  }

  async function enrichVisibleTreeCards() {
    let progress = false;

    for (const personEl of treeCardsDom()) {
      const id = String(attr(personEl, 'data-individual-id') || '');
      if (!id) continue;

      const person = await ensurePerson(id);
      if (person.treeProfile) continue;

      const wrapper = cardWrapper(personEl);
      if (!elementUsable(wrapper)) continue;

      activeTreePersonId = id;
      log(`tree profile click ${id}: ${person.listRow?.name || ''}`);

      syntheticClick(wrapper);
      const profile = await waitForTreeProfile(id);

      activeTreePersonId = null;

      if (profile) {
        progress = true;
      } else {
        log(`tree profile timeout ${id}`, 'warn');
      }

      await sleep(150);

      const crawler = await getCrawler();
      if (!crawler.enabled) break;
    }

    return progress;
  }

  async function expandOneRidge() {
    for (const ridge of openRidges()) {
      const key = ridgeKey(ridge);
      if (session.expandedRidges.has(key)) continue;

      session.expandedRidges.add(key);
      log('expand family branch');
      syntheticClick(ridge);
      await sleep(DOM_SETTLE);
      return true;
    }

    return false;
  }

  async function nextTreeTarget() {
    const people = await getAllStore('people');

    return people
      .filter(p =>
        !p.treeProfile &&
        !p.treeFailed &&
        (p.treeCenterAttempts || 0) < MAX_TREE_CENTER_ATTEMPTS
      )
      .sort((a, b) => {
        // Prefer people for whom People detail yielded a first-class tree URL.
        const aScore = a.peopleDetail?.person?.treePageLink ? 0 : 1;
        const bScore = b.peopleDetail?.person?.treePageLink ? 0 : 1;
        return aScore - bScore || Number(a.id) - Number(b.id);
      })[0] || null;
  }

  async function markCurrentTreeTargetAttempt() {
    const crawler = await getCrawler();
    if (!crawler.targetId) return;

    const person = await getPerson(crawler.targetId);
    if (!person || person.treeProfile) return;

    if ((person.treeCenterAttempts || 0) >= MAX_TREE_CENTER_ATTEMPTS) {
      person.treeFailed = true;
      await putPerson(person);
      log(`tree target failed ${person.id}`, 'warn');
    }
  }

  async function jumpToNextTreeTarget() {
    await markCurrentTreeTargetAttempt();

    const next = await nextTreeTarget();

    if (!next) {
      const people = await getAllStore('people');
      const remaining = people.filter(p => !p.treeProfile);

      log(`tree phase finished; unresolved=${remaining.length}`);

      await patchCrawler({
        phase: 'photo-inventory',
        targetId: null,
        lastAction: `tree finished unresolved=${remaining.length}`,
      });

      await photoInventoryPhase();
      return;
    }

    next.treeCenterAttempts = (next.treeCenterAttempts || 0) + 1;
    await putPerson(next);

    const treeUrl =
      absoluteUrl(next.peopleDetail?.person?.treePageLink) ||
      next.treePageLink ||
      await constructedTreeUrl(next.id);

    await patchCrawler({
      targetId: next.id,
      lastAction: `center tree on ${next.id}`,
    });

    await navigate(treeUrl, `center tree on ${next.id}`);
  }

  async function treePhase() {
    if (!location.pathname.startsWith('/family-trees/')) {
      await jumpToNextTreeTarget();
      return;
    }

    session.expandedRidges.clear();

    await waitForDomReady();
    await sleep(PAGE_SETTLE);

    for (let pass = 1; pass <= 50; pass++) {
      const crawler = await getCrawler();
      if (!crawler.enabled || crawler.phase !== 'tree') return;

      const profileProgress = await enrichVisibleTreeCards();

      const ridgeProgress = await expandOneRidge();
      if (ridgeProgress) continue;

      // Re-read after possible profile panel/tree updates.
      const visibleMissing = [];

      for (const el of treeCardsDom()) {
        const id = attr(el, 'data-individual-id');
        if (!id) continue;
        const p = await getPerson(id);
        if (!p?.treeProfile) visibleMissing.push(id);
      }

      if (!profileProgress && visibleMissing.length === 0) {
        break;
      }

      if (!profileProgress && !ridgeProgress) {
        break;
      }
    }

    await jumpToNextTreeTarget();
  }

  // ---------------------------------------------------------------------------
  // Photo inventory phase
  // ---------------------------------------------------------------------------

  function declaredMediaTotal(person) {
    const total = person?.peopleDetail?.media?.total;

    if (typeof total === 'number' && Number.isFinite(total)) {
      return total;
    }

    const parsed = Number(total);
    return Number.isFinite(parsed) ? parsed : null;
  }

  async function preflightPhotoInventory() {
    const people = await getAllStore('people');
    const photos = await getAllStore('photos');

    const ownerCounts = new Map();

    for (const photo of photos) {
      for (const owner of photo.owners || []) {
        const id = String(owner);
        ownerCounts.set(id, (ownerCounts.get(id) || 0) + 1);
      }
    }

    let noMedia = 0;
    let alreadyCovered = 0;

    for (const person of people) {
      if (person.photoInventoryScanned) continue;

      const total = declaredMediaTotal(person);
      const known = ownerCounts.get(String(person.id)) || 0;

      if (total === 0) {
        person.photoInventoryScanned = true;
        person.photoInventoryAttempts =
          (person.photoInventoryAttempts || 0) + 1;
        person.photoInventoryDeclaredTotal = 0;
        person.photoInventoryFound = 0;
        person.photoInventoryStatus = 'no-media-declared';
        await putPerson(person);
        noMedia += 1;
        continue;
      }

      // peopleDetail/treeProfile may already have exposed all photo IDs.
      // If the number of unique known photos for this person reaches the
      // declared media.total, photo-world cannot add another unique item.
      if (total != null && total > 0 && known >= total) {
        person.photoInventoryScanned = true;
        person.photoInventoryAttempts =
          (person.photoInventoryAttempts || 0) + 1;
        person.photoInventoryDeclaredTotal = total;
        person.photoInventoryFound = known;
        person.photoInventoryStatus = 'covered-by-known-media';
        await putPerson(person);
        alreadyCovered += 1;
      }
    }

    if (noMedia || alreadyCovered) {
      log(
        `photo preflight: no-media=${noMedia}, ` +
        `already-covered=${alreadyCovered}`
      );
    }
  }


  async function nextPhotoInventoryPerson() {
    await preflightPhotoInventory();

    const people = await getAllStore('people');

    return people
      .filter(p => !p.photoInventoryScanned)
      .sort((a, b) => {
        // Prefer people for whom MyHeritage explicitly declares media > 0.
        // Unknown totals are still scanned, but after known-positive targets.
        const at = declaredMediaTotal(a);
        const bt = declaredMediaTotal(b);
        const as = at > 0 ? 0 : 1;
        const bs = bt > 0 ? 0 : 1;

        return as - bs || Number(a.id) - Number(b.id);
      })[0] || null;
  }


  function photoLinksOnPage() {
    const results = [];

    for (const a of document.querySelectorAll('a[href*="/photo-"]')) {
      const href = absoluteUrl(a.getAttribute('href'));
      const id = extractPhotoIdFromUrl(href);

      if (id) {
        results.push({
          id,
          pageUrl: href,
          thumbUrl:
            absoluteUrl(a.querySelector('img')?.currentSrc) ||
            absoluteUrl(a.querySelector('img')?.src) ||
            parseBackgroundUrl(
              a.querySelector('[style*="background"]')?.style?.backgroundImage
            ),
        });
      }
    }

    for (const el of document.querySelectorAll('[data-photo-id]')) {
      const raw = attr(el, 'data-photo-id');
      const id = numericTail(raw) || String(raw || '').replace(/\D/g, '');

      if (!id) continue;

      const a = el.closest('a[href*="/photo-"]') ||
        el.querySelector?.('a[href*="/photo-"]');

      results.push({
        id,
        pageUrl: absoluteUrl(a?.getAttribute('href')),
        thumbUrl:
          absoluteUrl(el.querySelector?.('img')?.currentSrc) ||
          absoluteUrl(el.querySelector?.('img')?.src),
      });
    }

    return results;
  }

  async function scanPhotoWorldForPerson(personId) {
    let stableRounds = 0;
    let previousCount = -1;

    for (let round = 0; round < 18; round++) {
      const found = photoLinksOnPage();

      for (const item of found) {
        await upsertPhoto(item.id, {
          pageUrl: item.pageUrl,
          thumbUrl: item.thumbUrl,
          discovered: true,
        }, personId);
      }

      const currentCount = (await getAllStore('photos'))
        .filter(ph => (ph.owners || []).includes(String(personId))).length;

      if (currentCount === previousCount) stableRounds += 1;
      else stableRounds = 0;

      previousCount = currentCount;

      if (stableRounds >= 3) break;

      window.scrollTo({
        top: Math.max(
          document.body.scrollHeight,
          document.documentElement.scrollHeight
        ),
        behavior: 'instant',
      });

      await sleep(500);
    }

    return previousCount;
  }

  async function photoInventoryPhase() {
    if (await handlePhotoWorldLimitPage()) {
      await sleep(150);
    }

    if (await guardAccessState()) return;

    const next = await nextPhotoInventoryPerson();

    if (!next) {
      await patchCrawler({
        phase: 'photo-resolve',
        targetId: null,
        lastAction: 'photo inventory finished',
      });
      await photoResolvePhase();
      return;
    }

    const declaredTotal = declaredMediaTotal(next);

    if (!location.pathname.startsWith('/photo-world/')) {
      await patchCrawler({ targetId: next.id });
      await throttlePhotoWorldNavigation();
      await navigate(
        await photoWorldUrl(next.id),
        `photo inventory ${next.id}`
      );
      return;
    }

    const url = new URL(location.href);
    const currentId = url.searchParams.get('individual_id');

    // If MyHeritage redirected
    //   /photo-world?...&individual_id=<target>
    // to the global
    //   /photo-world/<site>
    // there is no person-specific photo world to scan.
    //
    // For media.total=0 this is expected and should be treated as completion,
    // never as a navigation mismatch to retry forever.
    if (!currentId) {
      const crawler = await getCrawler();

      if (crawler.targetId === next.id) {
        if (declaredTotal === 0) {
          next.photoInventoryScanned = true;
          next.photoInventoryAttempts =
            (next.photoInventoryAttempts || 0) + 1;
          next.photoInventoryDeclaredTotal = 0;
          next.photoInventoryFound = 0;
          next.photoInventoryStatus = 'redirected-no-media';
          await putPerson(next);

          log(`photo inventory ${next.id}: no media, redirect accepted`);

          await patchCrawler({
            targetId: null,
            lastAction: `photo inventory ${next.id}: no media`,
          });

          await photoInventoryPhase();
          return;
        }

        // Unknown/positive media count but redirected anyway: do not fight the
        // redirect. Record it once and continue. The media URLs already seen in
        // People-detail/tree-profile remain available for photo resolution.
        next.photoInventoryScanned = true;
        next.photoInventoryAttempts =
          (next.photoInventoryAttempts || 0) + 1;
        next.photoInventoryDeclaredTotal = declaredTotal;
        next.photoInventoryFound = 0;
        next.photoInventoryStatus = 'redirected-global-list';
        await putPerson(next);

        log(
          `photo inventory ${next.id}: redirected to global list` +
          (declaredTotal != null ? ` (declared=${declaredTotal})` : ''),
          declaredTotal > 0 ? 'warn' : 'info'
        );

        await patchCrawler({
          targetId: null,
          lastAction: `photo inventory ${next.id}: global redirect`,
        });

        await photoInventoryPhase();
        return;
      }
    }

    if (currentId !== next.id) {
      await patchCrawler({ targetId: next.id });
      await throttlePhotoWorldNavigation();
      await navigate(
        await photoWorldUrl(next.id),
        `photo inventory ${next.id}`
      );
      return;
    }

    await waitForDomReady();
    await sleep(PAGE_SETTLE);

    if (await handlePhotoWorldLimitPage()) {
      await photoInventoryPhase();
      return;
    }

    if (await guardAccessState()) return;

    const count = await scanPhotoWorldForPerson(next.id);

    next.photoInventoryScanned = true;
    next.photoInventoryAttempts = (next.photoInventoryAttempts || 0) + 1;
    next.photoInventoryDeclaredTotal = declaredTotal;
    next.photoInventoryFound = Math.max(0, count);
    next.photoInventoryStatus = 'scanned';
    await putPerson(next);

    log(
      `photo inventory ${next.id}: found=${Math.max(0, count)}` +
      (declaredTotal != null ? `, declared=${declaredTotal}` : '')
    );

    await patchCrawler({
      targetId: null,
      lastAction: `photo inventory ${next.id} complete`,
    });

    await photoInventoryPhase();
  }


  // ---------------------------------------------------------------------------
  // Photo resolve + download phase
  // ---------------------------------------------------------------------------

  function scoreImageUrl(url, photoId = null) {
    if (!url) return -1;

    let score = 0;
    const s = String(url);

    const m = s.match(/_(\d+)x(\d+)(?:C)?\//i);
    if (m) {
      score += Number(m[1]) * Number(m[2]);
    }

    // MyHeritage photo IDs observed in page URLs look like 1500276 while
    // mhcache object names use the tail, e.g. 500276_....
    if (photoId) {
      const tail = String(photoId).slice(-6);
      if (new RegExp(`[/_]${tail}_`, 'i').test(s)) {
        score += 100_000_000;
      }
    }

    if (/original|full|large/i.test(s)) score += 10_000_000;
    if (/72x72|96x96|128x128/i.test(s)) score -= 1_000_000;

    return score;
  }

  function imageCandidatesFromDom() {
    const urls = new Set(session.photoResolveCandidates);

    for (const img of document.images) {
      for (const candidate of [
        img.currentSrc,
        img.src,
        img.getAttribute('data-src'),
        img.getAttribute('data-original'),
      ]) {
        const u = absoluteUrl(candidate);
        if (
          u &&
          /(mhcache|myheritageimages|myheritage\.com)/i.test(u)
        ) {
          urls.add(u);
        }
      }
    }

    for (const el of document.querySelectorAll('[style*="background"]')) {
      const u = parseBackgroundUrl(getComputedStyle(el).backgroundImage);
      if (
        u &&
        /(mhcache|myheritageimages|myheritage\.com)/i.test(u)
      ) {
        urls.add(u);
      }
    }

    try {
      for (const entry of performance.getEntriesByType('resource')) {
        const u = entry.name;
        if (
          /(mhcache|myheritageimages)/i.test(u) &&
          /\.(?:jpe?g|png|webp)(?:[?#]|$)/i.test(u)
        ) {
          urls.add(u);
        }
      }
    } catch {}

    return [...urls];
  }

  function bestImageCandidate(photoId = null) {
    const candidates = imageCandidatesFromDom();

    return candidates
      .map(url => ({ url, score: scoreImageUrl(url, photoId) }))
      .sort((a, b) => b.score - a.score)[0]?.url || null;
  }

  async function nextPhotoToResolve() {
    const photos = await getAllStore('photos');

    return photos
      .filter(ph =>
        !ph.downloaded &&
        !ph.resolved &&
        ph.pageUrl &&
        (ph.resolveAttempts || 0) < MAX_PHOTO_RESOLVE_ATTEMPTS
      )
      .sort((a, b) => Number(a.id) - Number(b.id))[0] || null;
  }

  async function nextPhotoToDownload() {
    const photos = await getAllStore('photos');

    return photos
      .filter(ph =>
        !ph.downloaded &&
        (ph.largeUrl || ph.thumbUrl)
      )
      .sort((a, b) => Number(a.id) - Number(b.id))[0] || null;
  }

  function extFromUrl(url) {
    try {
      const p = new URL(url).pathname;
      const m = p.match(/(\.(?:jpe?g|png|webp))$/i);
      return m ? m[1].toLowerCase() : '.jpg';
    } catch {
      return '.jpg';
    }
  }

  async function downloadPhoto(photo) {
    const url = photo.largeUrl || photo.thumbUrl;
    if (!url) return false;

    const filename =
      `${PREFIX}photos__${safeName(photo.id)}` +
      `${extFromUrl(url)}`;

    log(`download photo ${photo.id}`);

    const ok = await new Promise(resolve => {
      try {
        GM_download({
          url,
          name: filename,
          saveAs: false,
          onload: () => resolve(true),
          onerror: e => {
            log(
              `photo ${photo.id} download error: ${e?.error || 'unknown'}`,
              'warn'
            );
            resolve(false);
          },
          ontimeout: () => resolve(false),
        });
      } catch (e) {
        log(`GM_download ${photo.id}: ${e.message}`, 'warn');
        resolve(false);
      }
    });

    photo.downloaded = ok;
    photo.downloadedAt = ok ? nowIso() : photo.downloadedAt;
    photo.downloadError = ok ? null : 'download failed';
    await putStoreValue('photos', photo);

    return ok;
  }

  async function photoResolvePhase() {
    // First download every photo for which tree JSON already exposed a large URL.
    let downloadable = await nextPhotoToDownload();

    if (downloadable && downloadable.resolved) {
      await downloadPhoto(downloadable);
      await photoResolvePhase();
      return;
    }

    const next = await nextPhotoToResolve();

    if (!next) {
      // Some media entries only expose thumbnails/page links. Download the best
      // known URL even when resolution failed, but never redownload success.
      downloadable = await nextPhotoToDownload();

      if (downloadable) {
        await downloadPhoto(downloadable);
        await photoResolvePhase();
        return;
      }

      await patchCrawler({
        phase: 'done',
        targetId: null,
        enabled: false,
        lastAction: 'export crawl finished',
      });

      log('all phases finished');
      await exportAll();
      return;
    }

    const currentPhotoId = extractPhotoIdFromUrl(location.href);

    if (
      !location.pathname.startsWith('/photo-') ||
      currentPhotoId !== next.id
    ) {
      next.resolveAttempts = (next.resolveAttempts || 0) + 1;
      await putStoreValue('photos', next);

      await patchCrawler({ targetId: next.id });
      await navigate(next.pageUrl, `resolve photo ${next.id}`);
      return;
    }

    await waitForDomReady();
    await sleep(1500);

    const best = bestImageCandidate(next.id);

    if (best) {
      next.largeUrl = best;
      next.resolved = true;
      next.downloadError = null;
      await putStoreValue('photos', next);

      log(`photo resolved ${next.id}`);

      await downloadPhoto(next);
    } else {
      if ((next.resolveAttempts || 0) >= MAX_PHOTO_RESOLVE_ATTEMPTS) {
        next.resolved = true; // resolved as "best known only"; prevents loop
      }
      await putStoreValue('photos', next);
      log(`photo resolve failed ${next.id}`, 'warn');
    }

    await photoResolvePhase();
  }

  // ---------------------------------------------------------------------------
  // Export / reports
  // ---------------------------------------------------------------------------

  async function counts() {
    const people = await getAllStore('people');
    const photos = await getAllStore('photos');

    return {
      inventory: people.filter(p => p.listRow).length,
      peopleDetail: people.filter(p => p.peopleDetail).length,
      detailFailed: people.filter(p => p.detailFailed && !p.peopleDetail).length,
      treeProfile: people.filter(p => p.treeProfile).length,
      treeFailed: people.filter(p => p.treeFailed && !p.treeProfile).length,
      photoInventory: people.filter(p => p.photoInventoryScanned).length,
      photos: photos.length,
      photosResolved: photos.filter(p => p.resolved).length,
      photosDownloaded: photos.filter(p => p.downloaded).length,
      peopleTotal: people.length,
      familyTreeSize: await metaGet('familyTreeSize', null),
    };
  }

  async function buildExport() {
    const people = await getAllStore('people');
    const photos = await getAllStore('photos');
    const site = await metaGet('site', {});
    const crawler = await getCrawler();

    return {
      meta: {
        source: 'MyHeritage',
        exporter: 'MyHeritage Full Personal Exporter',
        version: VERSION,
        exportedAt: nowIso(),
        site,
        familyTreeSize: await metaGet('familyTreeSize', null),
        crawler,
      },
      people: Object.fromEntries(people.map(p => [p.id, p])),
      photos: Object.fromEntries(photos.map(p => [p.id, p])),
      stats: await counts(),
    };
  }

  async function buildMissingReport() {
    const people = await getAllStore('people');

    return {
      generatedAt: nowIso(),
      stats: await counts(),
      missingPeopleDetail: people
        .filter(p => !p.peopleDetail)
        .map(p => ({
          id: p.id,
          name: p.listRow?.name || null,
          page: p.listPage,
          failed: !!p.detailFailed,
        })),
      missingTreeProfile: people
        .filter(p => !p.treeProfile)
        .map(p => ({
          id: p.id,
          name: p.listRow?.name || p.peopleDetail?.person?.name || null,
          attempts: p.treeCenterAttempts || 0,
          failed: !!p.treeFailed,
          treePageLink:
            p.peopleDetail?.person?.treePageLink ||
            p.treePageLink ||
            null,
        })),
    };
  }

  async function exportAll() {
    const exportData = await buildExport();
    const raw = await getAllStore('raw');
    const missing = await buildMissingReport();

    downloadBlob(
      `${PREFIX}export.json`,
      JSON.stringify(exportData, null, 2)
    );

    await sleep(250);

    downloadBlob(
      `${PREFIX}raw__responses.json`,
      JSON.stringify(raw, null, 2)
    );

    await sleep(250);

    downloadBlob(
      `${PREFIX}missing.json`,
      JSON.stringify(missing, null, 2)
    );

    log('export files queued');
  }

  // ---------------------------------------------------------------------------
  // Control
  // ---------------------------------------------------------------------------

  async function startCrawler({ restart = false } = {}) {
    if (restart) {
      await clearAllData();
    }

    const crawler = await getCrawler();

    if (crawler.phase === 'idle' || crawler.phase === 'done') {
      await patchCrawler({
        enabled: true,
        phase: 'inventory',
        targetId: null,
        startedAt: nowIso(),
        lastAction: 'start',
      });
    } else {
      await patchCrawler({
        enabled: true,
        lastAction: 'resume',
      });
    }

    await runCurrentPhase();
  }

  async function pauseCrawler() {
    await patchCrawler({
      enabled: false,
      lastAction: 'paused by user',
    });
    log('paused');
    await refreshPanel();
  }

  async function clearAllData() {
    await Promise.all([
      clearStore('people'),
      clearStore('photos'),
      clearStore('raw'),
      clearStore('meta'),
    ]);

    session.expandedRidges.clear();
    session.responseFingerprints.clear();
    session.photoResolveCandidates.clear();

    log('all exporter data cleared');
  }

  async function resetCrawler() {
    const yes = confirm(
      'Clear MyHeritage Exporter IndexedDB state and start from zero?'
    );
    if (!yes) return;

    await clearAllData();
    await persistDetectedContext();
    await patchCrawler({
      enabled: false,
      phase: 'idle',
      targetId: null,
      lastAction: 'reset',
    });
    await refreshPanel();
  }

  async function runCurrentPhase() {
    if (pageRunnerActive) return;

    const crawler = await getCrawler();
    if (!crawler.enabled) return;

    if (await guardAccessState()) return;

    pageRunnerActive = true;

    try {
      if (crawler.phase === 'inventory') {
        await inventoryPhase();
      } else if (crawler.phase === 'people-detail') {
        await peopleDetailPhase();
      } else if (crawler.phase === 'tree') {
        await treePhase();
      } else if (crawler.phase === 'photo-inventory') {
        await photoInventoryPhase();
      } else if (crawler.phase === 'photo-resolve') {
        await photoResolvePhase();
      } else if (crawler.phase === 'done') {
        await patchCrawler({ enabled: false });
      }
    } catch (e) {
      console.error('[MHX]', e);
      log(`runner error: ${e.message}`, 'warn');
      await patchCrawler({
        enabled: false,
        lastAction: `error: ${e.message}`,
      });
    } finally {
      pageRunnerActive = false;
      await refreshPanel();
    }
  }

  // ---------------------------------------------------------------------------
  // Panel
  // ---------------------------------------------------------------------------

  function log(message, level = 'info') {
    const line = `${new Date().toLocaleTimeString()} ${message}`;

    if (level === 'warn') console.warn('[MHX]', message);
    else console.log('[MHX]', message);

    currentLog.unshift({ line, level });
    currentLog = currentLog.slice(0, 14);

    const box = document.getElementById('mhx-log');
    if (box) renderLog(box);
  }

  function renderLog(box) {
    box.innerHTML = '';

    for (const item of currentLog) {
      const div = document.createElement('div');
      div.textContent = item.line;
      if (item.level === 'warn') div.style.color = '#f3bf61';
      box.appendChild(div);
    }
  }

  function styleButton(btn) {
    Object.assign(btn.style, {
      background: '#333',
      color: '#fff',
      border: '1px solid #666',
      borderRadius: '5px',
      padding: '4px 7px',
      cursor: 'pointer',
      fontSize: '11px',
    });
  }

  async function refreshPanel() {
    const statsEl = document.getElementById('mhx-stats');
    if (!statsEl || !dbReady) return;

    const crawler = await getCrawler();
    const c = await counts();

    statsEl.innerHTML = [
      `v${VERSION} — <b>${crawler.enabled ? 'RUNNING' : 'idle'}</b>`,
      `phase: <b>${crawler.phase}</b>`,
      `inventory: ${c.inventory}/${c.familyTreeSize ?? c.peopleTotal ?? '?'}`,
      `people detail: ${c.peopleDetail}/${c.peopleTotal}`,
      `tree profile: ${c.treeProfile}/${c.peopleTotal}`,
      `photo worlds: ${c.photoInventory}/${c.peopleTotal}`,
      `photos: ${c.photos}`,
      `resolved: ${c.photosResolved}`,
      `downloaded: ${c.photosDownloaded}`,
      crawler.targetId ? `target: ${crawler.targetId}` : 'target: —',
      crawler.lastAction
        ? `<span style="color:#aaa">${safeName(crawler.lastAction, 55)}</span>`
        : '',
    ].filter(Boolean).join('<br>');
  }

  function createPanel() {
    if (document.getElementById('mhx-panel')) return;

    const panel = document.createElement('div');
    panel.id = 'mhx-panel';

    panel.innerHTML = `
      <div style="font-weight:700;margin-bottom:7px">
        MyHeritage Exporter
      </div>

      <div id="mhx-stats"
           style="font:12px/1.45 ui-monospace,monospace;margin-bottom:8px">
        loading…
      </div>

      <div style="display:flex;flex-wrap:wrap;gap:5px;margin-bottom:7px">
        <button id="mhx-start">Start / Resume</button>
        <button id="mhx-pause">Pause</button>
        <button id="mhx-export">Export now</button>
        <button id="mhx-reset">Reset</button>
      </div>

      <div id="mhx-log"
           style="max-height:175px;overflow:auto;
                  font:11px/1.35 ui-monospace,monospace;
                  border-top:1px solid #555;padding-top:6px">
      </div>
    `;

    Object.assign(panel.style, {
      position: 'fixed',
      right: '12px',
      bottom: '12px',
      zIndex: '2147483647',
      width: '350px',
      maxHeight: '390px',
      overflow: 'auto',
      background: 'rgba(25,25,25,.96)',
      color: '#eee',
      padding: '10px',
      border: '1px solid #666',
      borderRadius: '8px',
      boxShadow: '0 5px 25px rgba(0,0,0,.35)',
      fontFamily: 'system-ui, sans-serif',
    });

    document.documentElement.appendChild(panel);

    panel.querySelectorAll('button').forEach(styleButton);

    document.getElementById('mhx-start').onclick = () => {
      startCrawler().catch(e => log(e.message, 'warn'));
    };

    document.getElementById('mhx-pause').onclick = () => {
      pauseCrawler().catch(e => log(e.message, 'warn'));
    };

    document.getElementById('mhx-export').onclick = () => {
      exportAll().catch(e => log(e.message, 'warn'));
    };

    document.getElementById('mhx-reset').onclick = () => {
      resetCrawler().catch(e => log(e.message, 'warn'));
    };

    renderLog(document.getElementById('mhx-log'));
    refreshPanel().catch(() => {});
  }

  // ---------------------------------------------------------------------------
  // Boot
  // ---------------------------------------------------------------------------

  async function boot() {
    try {
      db = await openDb();
      dbReady = true;

      await persistDetectedContext();

      const discoveredCsrf =
        observedCsrfToken || discoverCsrfTokenInDocument();

      if (discoveredCsrf) {
        await rememberCsrfToken(discoveredCsrf);
      }

      const queued = captureQueue;
      captureQueue = [];

      for (const item of queued) {
        await absorbJson(item.payload, item.url);
      }

      await waitForDomReady();
      createPanel();

      if (panelTimer) clearInterval(panelTimer);
      panelTimer = setInterval(() => {
        refreshPanel().catch(() => {});
      }, 1200);

      // Continue automatically after full-page navigation/reload.
      const crawler = await getCrawler();

      if (crawler.enabled) {
        log(`resume phase=${crawler.phase}`);
        setTimeout(() => {
          runCurrentPhase().catch(e => log(e.message, 'warn'));
        }, 800);
      }

      W.MHX = {
        version: VERSION,
        start: startCrawler,
        pause: pauseCrawler,
        reset: resetCrawler,
        export: exportAll,
        run: runCurrentPhase,
        counts,
        people: () => getAllStore('people'),
        photos: () => getAllStore('photos'),
        raw: () => getAllStore('raw'),
        crawler: getCrawler,
        csrfToken: getCsrfToken,
      };

      console.log('[MHX] ready', VERSION);
    } catch (e) {
      console.error('[MHX] boot failed', e);
    }
  }

  boot();
})();
